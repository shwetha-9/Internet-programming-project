<?php
session_start();

$user = filter_input(INPUT_POST,'user');
$email = filter_input(INPUT_POST,'email');
$pass = filter_input(INPUT_POST,'pass');
$conpass = filter_input(INPUT_POST,'conpass');
$mobile = filter_input(INPUT_POST,'mobile');
date_default_timezone_set("Asia/Kolkata");
$dates=date('m/d/Y h:i:s a', time());
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "user";

//create connection

$conn = mysqli_connect($host,$dbusername,$dbpassword,$dbname);
if(mysqli_connect_error()) {
die('Connect Error ('.mysqli_connect_errno().')'.mysqli_connect_error());
}
else {
 $sql = "INSERT INTO pop(user,pass,conpass,mobile,email,logintime)
 values ('$user','$pass','$conpass','$mobile','$email','$dates')";
 if($conn->query($sql)) {
 	$_SESSION['email']=$email;
	header('location:beforehome.php');
 }
 else {
 	?><script>
		window.alert("Email-Id Already Exists");
		window.location.href='registrationpage.php';
	</script>;<?php
 }
 $conn->close();
}
?>