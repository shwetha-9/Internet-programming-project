<?php

session_start();
if(!isset($_SESSION['email'])){
	header("location:log.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Tips</title>
<link href="logo.png" rel="icon" type="image/ico">
<style> 

body
{background-image:url(https://images.pexels.com/photos/1308624/pexels-photo-1308624.jpeg?auto=compress&cs=tinysrgb&h=650&w=940);
}
h1{
color:khaki;}
p{
color:white;
font-size:20px;

}

</style>
</head>
<body>
     <h1> Tips For HealthCare</h1>
     <img src=" /img1.jpg" width=" 890"height="490" style="float:center;margin-left:190px; margin-right:400; padding:2px" alt="Sorry image not found">
	 <h1>Drink Tea</h1>
	 <img src=" /img15.jpg" width=" 240"height="90" style="float:left;margin-top:2px; padding:2px" alt="Sorry image not found"> 
	<p>Coffee stresses your adrenal glands and it really isnt all that great for you. Good quality green tea gives you a milder kick, but it lasts a lot longer than coffee and its less irritating for your nervous system. Bonus: It speeds up your metabolism and burns fat.</p><hr>
	<img src=" /img2.jpg" width=" 240"height="140" style="float:right;margin-top:2px; padding:2px" alt="Sorry image not found"> 
   <h1 align="left">Use Menthol</h1> 
	<p text-align"justify">Muscles feeling sore, or your head giving you problems? Rub a bit of menthol cream (such as Tiger Balm or Vicks VapoRub) into your achy parts, and you will feel so much better</p><hr> 
	<img src=" /img7.jpg" width=" 290"height="150" style="float:left; padding:2px" alt="Sorry image not found">
	 <h1>Add Ginger Liberally</h1> 
	<p align"justify">This is one of my favorite ingredients, and it makes for one of the best daily health tips too!  Strong ginger tea kills sore throats, eliminates congestion, and it will give you the kick you need to wake up when you are tired.</p><hr> 
	<img src=" /img8.jpg" width=" 290"height="140" style="float:right; padding:2px" alt="Sorry image not found"> 
	 <h1 align="left">Do Puzzles</h1> 	
	<p>I love puzzles, and they help to keep my mind sharp. I do my puzzles as a break in my work day, and it helps to relax me while keeping both my hands and brain occupied. Why are they so great? Doing puzzles and other mental oriented activities will stave off Alzheimers and keep you sharp for years to come.</p><hr> 
	 <h1>Sniff an Apple</h1> 
	 <img src=" /img9.jpg" width="200"height="90" style="float:left; padding:1px" alt="Sorry image not found"> 
	<p>I have actually tried this one, and it works!<br> If you are hungry, get a healthy apple and hold it up to your nose. Take a dozen or so deep breaths, and get back to work. Your hunger pangs will be gone!</p><hr>
	<img src=" /img10.jpg" width=" 290"height="140" style="float:right; padding:2px" alt="Sorry image not found"> 
	 <h1>Chew Gum</h1> 
	<p>Sugarless gum is a major part of my day, as it helps me to focus on what I am doing. Its low in sugar and calories, and it keeps my mind zeroed in on my writing. As a bonus, it keeps me from getting hungry too!</p> <hr>
	<img src=" /img11.jpg" width=" 290"height="140" style="float:left; padding:2px" alt="Sorry image not found">  
	 <h1>Drop a Yolk</h1> 
	<p>Want a quick snack to carry you over until lunch time? Cook up one full free range egg and one egg white, saving the other yolk for cooking or baking. The egg/egg white combo will give you fewer than 100 calories, but it will be a tasty treat to keep you from being hungry.</p><hr>
	<img src=" /img3.jpg" width=" 290"height="140" style="float:right; padding:2px" alt="Sorry image not found"> 
	 <h1>Stretch</h1> 
	<p>Bored while watching TV? Sit on your living room floor and do some stretches. You will find that working your body will help your mind focus on what you are doing, and occupying your mind will help you to stretch without cringing at the pain of trying to do the splits or a back bend.</p><hr>
	<img src=" /img12.jpg" width=" 290"height="180" style="float:left; padding:2px" alt="Sorry image not found">   
	 <h1>Set a Water Goal</h1> 
	<p>You know you need to drink more water, so make it a goal to drink a bit more each day.<br>Drink a cup or two every hour on the hour, or have a water bottle at your desk that you empty out whenever you remember it. Starting the day with a big glass of water and fresh lemon juice is particularly energizing.</p> <hr> 
	<img src=" /img5.jpg" width=" 290"height="160" style="float:right; padding:2px" alt="Sorry image not found"> 
	 <h1>Drink Cranberry Juice</h1> 
	<p>Cranberries are loaded with Vitamin C, which will flush out your body and boost your immune system. Make sure the juice is unsweetened, and enjoy that tangy goodness as it gives you the health kick you need.</p><hr> 
	<img src=" /img2.jpg" width=" 290"height="140" style="float:left; padding:2px" alt="Sorry image not found"> 
	 <h1>Have a Mint</h1> 
	<p>Stomach causing you problems after a heavy meal? Have a peppermint to help soothe your stomach, or drink a glass of mint tea. You can say goodbye to acid reflux or indigestion.</p><hr>
	<img src=" /img14.jpg" width=" 290"height="160" style="float:right; padding:2px" alt="Sorry image not found">   
	 <h1>Get Out</h1> 
	<p>Spend more time in the sun, at least 30 minutes a day. Your body needs more Vitamin D, and it gets it from the UV rays of the sun. Dont wear sunblock, but just spend enough time in the sun to get a small amount of color without full on burning.</p><hr> 
   <h1>Best   Remedies For Good Health</h1>
   <img src=" /img.jpg" width=" 990"height="490" style="float:center; margin-left:10px; padding:2px" alt="Sorry image not found">
   <p><b>1.</b>Having pomegranates juice daily is good for heart and useful for people suffering from low Blood Pressure (Hypotension)</p>
   <p><b>2.</b>One natural treatment for acidity is chewing a few Basil (tulsi) leaves after a meal.This not just works as an antacid as it helps the body absorb food but also prevents reflux and the formation of ulcers. </p>
   <p><b>3.</b>Sucking a piece of Clove after meal helps in reducing acidity problem.</p>
   <p><b>4.</b>A flake of garlic swallowed with water taken empty stomach daily in the morning can be helpful in solving many stomach & gastric problems.</p>
   <p><b>5.</b>Headache caused by summer heat is cured by consuming watermelon juice.  Just one glass a day works wonders.</p>
   <p><b>6.</b>Open 6 dates and boil in 1/2 liter of milk for 25 minutes over low heat. Drink three cups a day.  This is ultimate dry cough remedy.</p>
   <p><b>7.</b>Eating an Apple on an empty stomach in the morning relieves one of migraine pain. This must be done for a few mornings.  I have been a migraine patient for past 10 years and this one worked most for me.</p>
   <p><b>8.</b>Mix 2 teaspoons of honey with equal quantity of ginger juice. The concoction helps to expectorate mucus, providing relief for the common cold, coughs and sore throat.</p>
   <p><b>9.</b>Eat before breakfast half cup of cooked beets if you suffer from chronic constipation or indigestion.</p>
   <p><b>10.</b>Ayurveda cough syrup at  . Peel and chop six medium onions. Put the pieces in a container and add four tablespoons of honey. Cover and leave them in a water bath over low heat for two hours. Strain and take one tablespoon every three hours.</p>
   <p><b>11.</b>Grated cucumber applied over the face, eyes and neck for fifteen minutes is very beneficial for acne and blackheads.</p>
   <p><b>12.</b>A simple remedy for Anemia or iron deficiency--Pound 3-4 soft dates with milk and add a little ghee in it.Eating this mixture will help to prevent Anemia.</p>
   <p><b>13.</b>  Remedies Treatment for Cough--For severe cough, mix tulsi juice with garlic juice and honey.A teaspoon of this mixture is taken once every three hours will treat excessive coughing.</p>
   <p><b>14.</b>When you suffer from a hangover ,a banana milkshake with honey can give you immense relief. Cold milk soothes the stomach lining and bananas with honey build up depleted blood sugar levels.</p>
   <p><b>15.</b>Lemon is one of the richest sources of Vitamin C on the planet and it also contains nutrients like Vitamin B, riboflavin, phosphorus, magnesium, and calcium. Lemon juice with warm water can also help eliminate waste in your system and serve as a Liver tonic. Daily intake of lemon water has several health benefits: It keeps your stomach healthy; acts as cure for nausea, heartburn, indigestion, high blood pressure, stress, and depression.</p>
   <p><b>16.</b>A few fennel seeds in a pot of hot water, and then boil it for five minutes on a low temperature. Strain the solution and then drink it. You can also chew the fresh fennel leafy plants if you can bear the taste. Else you can take a mixture of fennel, cardamom and mint leaves and boil them in water to make a concoction that can help during stomach gas.  This is very effective   Remedy for Gas and Bloating.</p>
   <p><b>17.</b>A drop garlic juice into your ear helps to relieve the pain of an ear infection.</p>
   <p><b>18.</b> A mixture of baking soda and lemon juice applied underarms will reduce body odor.</p>
   <p><b>19.</b>Best natural remedy for sore throat is to gargle with turmeric and salt. Mix:  ½ cup of warm water ½ tsp salt ¼ tsp powdered turmeric  After you gargle, don not drink or eat anything for at least ½ hr for the salt and turmeric to do their job of killing bacteria. You can repeat this as often as you need throughout the day.</p>
</body>
</html>