<?php

session_start();
if(!isset($_SESSION['email'])){
	header("location:log.php");
}
?>
<img src="Owhiro-Bay-Wellington-NZ-DSC5125-4-by-cleansurf2-1.jpg" alt="" /><!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
<title>Our vission</title>
<link href="logo.png" rel="icon" type="image/ico">
<style>
body{
background-color:darkblue;
background-image:url(http://www.sbshospital.com/wp-content/uploads/2013/09/Our-Philosphy.jpg);
background-repeat:no-repeat;
background-size:cover;
 }  
</head>
</style>
</html>